#guideactivity

用非常简单的方式实现开机引导页

![](https://dn-mhke0kuv.qbox.me/265ca8d77d6be0ae3652.gif)