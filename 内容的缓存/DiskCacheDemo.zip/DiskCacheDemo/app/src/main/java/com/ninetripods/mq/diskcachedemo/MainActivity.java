package com.ninetripods.mq.diskcachedemo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements LoadAsyncTask.ILoadStatus {

    private static final String TAG = "MainActivity";
    private final Object mDiskCacheLock = new Object();
    private static final int MAX_SIZE = 10 * 1024 * 1024;
    private DiskLruCache diskLruCache;
    private ImageView iv_img;
    private TextView tv_status;
    private StringBuilder builder;
    private Button btn_delete, btn_getSize, btn_getDir;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initEvents();
        initDiskLruCache();
        new LoadAsyncTask(this).execute(diskLruCache);
    }

    private void initViews() {
        btn_getDir = (Button) findViewById(R.id.btn_getDir);
        btn_getSize = (Button) findViewById(R.id.btn_getSize);
        btn_delete = (Button) findViewById(R.id.btn_delete);
        iv_img = (ImageView) findViewById(R.id.iv_img);
        tv_status = (TextView) findViewById(R.id.tv_status);
        builder = new StringBuilder();
    }

    private void initEvents() {
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeCache();
            }
        });
        btn_getSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCacheSize();
            }
        });
        btn_getDir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCacheDirStr();
            }
        });
    }

    @Override
    public void OnBeforeLoad() {
        Log.e(TAG, "OnBeforeLoad");
        builder.append("开始下载图片...\n");
        tv_status.setText(builder);
    }

    @Override
    public void OnDataTransfer() {
        Log.e(TAG, "OnDataTransfer");
        builder.append("下载图片完成，开始缓存图片...\n");
        tv_status.setText(builder);
    }

    @Override
    public void OnDataLoaded() {
        Log.e(TAG, "OnDataLoaded");
        builder.append("缓存成功，开始从缓存中取出图片并展示...\n");
        tv_status.setText(builder);
        Bitmap bitmap = getCache();
        if (bitmap != null) {
            iv_img.setImageBitmap(bitmap);
        }
    }

    private void initDiskLruCache() {
        if (diskLruCache == null || diskLruCache.isClosed()) {
            try {
                File cacheDir = Util.getDiskCacheDir(this, "CacheDir");
                if (!cacheDir.exists()) {
                    cacheDir.mkdirs();
                }
                diskLruCache = DiskLruCache.open(cacheDir, 1, 1, MAX_SIZE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Bitmap getCache() {
        try {
            String key = Util.hashKeyForDisk(Util.IMG_URL);
            DiskLruCache.Snapshot snapshot = diskLruCache.get(key);
            if (snapshot != null) {
                InputStream in = snapshot.getInputStream(0);
                return BitmapFactory.decodeStream(in);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void removeCache() {
        try {
            String key = Util.hashKeyForDisk(Util.IMG_URL);
            boolean isDelete = diskLruCache.remove(key);
            if (isDelete) {
                builder.append("删除缓存成功...\n");
            } else {
                builder.append("删除缓存失败...\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            builder.append("删除缓存失败...\n");
        } finally {
            tv_status.setText(builder);
        }
    }

    private long getCacheSize() {
        Log.e(TAG, "diskLruCache.size() is " + diskLruCache.size());
        DecimalFormat df = new DecimalFormat("#.00");
        //byte转换为kb
        String size = diskLruCache.size() != 0
                ? df.format(diskLruCache.size() / 1024f) + "kb"
                : "0kb";
        builder.append("缓存图片的大小...").append(size).append("\n");
        tv_status.setText(builder);
        return diskLruCache.size();
    }

    private void getCacheDirStr() {
        File file = diskLruCache.getDirectory();
        if (!file.exists()) return;
        Log.e(TAG, "diskLruCache.getDirectory().getPath() is " + diskLruCache.getDirectory().getPath());
        builder.append("缓存图片的地址...").append(diskLruCache.getDirectory().getPath()).append("\n");
        tv_status.setText(builder);
    }
}
