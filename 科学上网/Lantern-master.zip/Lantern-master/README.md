# Lantern
科学上网工具，轻松就可以访问google、facebook等被墙的网站。

# Usage
下载lantern.exe.fbd文件，将.fbd后缀去掉，双击运行即可。可能360会阻止运行，要点击允许。

mac系统使用lantern-installer-beta.dmg，安装打开即可。

如下图：
![image](https://github.com/liuling07/Lantern/raw/master/20151111215158.png)

该工具只能用于PC端浏览器浏览被墙网站，一般查资料够用了。如果需要玩游戏或者其他用途，建议还是买VPN。
