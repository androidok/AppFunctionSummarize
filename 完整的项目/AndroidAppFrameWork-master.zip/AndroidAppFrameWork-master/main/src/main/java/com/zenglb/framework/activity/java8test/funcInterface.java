package com.zenglb.framework.activity.java8test;

/**
 * 函数式接口
 * Created by zenglb on 2017/5/3.
 */
public class funcInterface {

}
