package com.zenglb.androidndk;

/**
 * Created by zenglb on 2017/4/26.
 */
public class NDKinterface {
//    static {
//        System.loadLibrary("En1Decrypt");
//    }
//
//    public static native String getAESEncrypt(String str);
//
//    public static native String getAESDecrypt(String str);

}