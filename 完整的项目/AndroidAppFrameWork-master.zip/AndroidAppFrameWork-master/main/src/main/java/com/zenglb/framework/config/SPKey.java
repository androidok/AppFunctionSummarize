package com.zenglb.framework.config;

/**
 * Created by zenglb on 2017/2/8.
 */

public class SPKey {
    public static final String KEY_ACCESS_TOKEN = "KEY_ACCESS_TOKEN";
    public static final String KEY_REFRESH_TOKEN = "KEY_REFRESH_TOEKN";
    public static final String KEY_LAST_ACCOUNT = "KEY_LAST_ACCOUNT";

}
