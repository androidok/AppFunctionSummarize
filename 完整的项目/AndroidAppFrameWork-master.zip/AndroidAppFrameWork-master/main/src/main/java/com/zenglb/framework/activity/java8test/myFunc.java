package com.zenglb.framework.activity.java8test;


/**
 * Created by zenglb on 2017/5/3.
 */

public class myFunc implements defaultFunc {

}
