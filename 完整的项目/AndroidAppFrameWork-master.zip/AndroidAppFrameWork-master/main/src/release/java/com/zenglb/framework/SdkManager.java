package com.zenglb.framework;

import android.content.Context;


/**
 * 正式发行 release 需要的
 * <p>
 * Created by zenglb on 2017/4/24.
 */
public class SdkManager {
    public static void initDebugOrRelease(Context context) {
        /**
         * Debug need init ,在这里全部注释
         */


        /**
         * Release need init ,在这里全部打开
         */
//        Stetho.initializeWithDefaults(context);

    }
}