package com.zenglb.baselib.jsbridge;

/**
 *
 */
public interface IBridge {

}
