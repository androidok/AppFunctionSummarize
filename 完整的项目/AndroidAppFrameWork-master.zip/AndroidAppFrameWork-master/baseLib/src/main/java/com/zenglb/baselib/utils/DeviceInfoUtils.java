package com.zenglb.baselib.utils;

/**
 * 获取设备的IMEI，WiFi ，基站等等 和设备有关的信息
 *
 * Created by zenglb on 2017/3/14.
 */
public class DeviceInfoUtils {

}
