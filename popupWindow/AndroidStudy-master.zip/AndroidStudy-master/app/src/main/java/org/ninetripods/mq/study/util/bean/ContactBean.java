package org.ninetripods.mq.study.util.bean;

/**
 * Created by MQ on 2017/5/16.
 */

public class ContactBean {
    private String indexTag;
    private String name;

    public String getIndexTag() {
        return indexTag;
    }

    public void setIndexTag(String indexTag) {
        this.indexTag = indexTag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
