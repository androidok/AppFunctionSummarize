package org.ninetripods.mq.study.util.interf;

import android.view.View;

/**
 * Created by MQ on 2017/3/13.
 */

public interface MyOnclickListener {
     void onItemClick(View view, int position);
}
