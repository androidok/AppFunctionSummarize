package org.ninetripods.mq.study.customView.cakeView;

import java.io.Serializable;

/**
 * Created by MQ on 2016/12/15.
 */

public class CakeBean implements Serializable {
    public String name;//名字
    public float value;//值
    public float degree;//旋转过的角度
    public int mColor;//圆弧颜色
}
