package org.ninetripods.mq.study.util;

/**
 * Created by MQ on 2017/3/30.
 */

public class Constant {
    public static final String BLOG_URL = "http://www.jianshu.com/u/185028550381";
    public static final String PROCESS_URL = "http://www.jianshu.com/p/ab3f6a2d8486";
    public static final String SERVER_APK_URL = "https://www.pgyer.com/pvxH";
}
