package com.wooplr.spotlight.utils;


/**
 * Created by jitender on 10/06/16.
 */

public interface SpotlightListener {

    void onUserClicked(String spotlightViewId);
}
