package uk.co.deanwild.materialshowcaseview;


public interface IDetachedListener {
    void onShowcaseDetached(MaterialShowcaseView showcaseView, boolean wasDismissed);
}
